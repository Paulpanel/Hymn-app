const hymns = [
    { 
        title: "Amazing Grace", 
        lyrics: "Amazing grace! How sweet the sound...",
        audio: "https://www.sample-videos.com/audio/mp3/crowd-cheering.mp3"
    },
    { 
        title: "How Great Thou Art", 
        lyrics: "O Lord my God! When I in awesome wonder...",
        audio: "https://www.sample-videos.com/audio/mp3/wave.mp3"
    }
];

// Function to Display Hymns
function displayHymns(filter = "") {
    const hymnList = document.getElementById("hymnList");
    hymnList.innerHTML = ""; // Clear previous hymns

    hymns.filter(hymn => hymn.title.toLowerCase().includes(filter.toLowerCase()))
         .forEach(hymn => {
        const hymnCard = document.createElement("div");
        hymnCard.classList.add("hymn-card");
        hymnCard.innerHTML = `
            <h2>${hymn.title}</h2>
            <p>${hymn.lyrics}</p>
            <audio controls>
                <source src="${hymn.audio}" type="audio/mpeg">
                Your browser does not support the audio element.
            </audio>
        `;
        hymnList.appendChild(hymnCard);
    });
}

// Search Functionality
document.getElementById("searchBar").addEventListener("input", (event) => {
    displayHymns(event.target.value);
});

// Initial Load
displayHymns();
const hymns = [
    { 
        title: "Amazing Grace", 
        lyrics: "Amazing grace! How sweet the sound...",
        audio: "https://www.sample-videos.com/audio/mp3/crowd-cheering.mp3"
    },
    { 
        title: "How Great Thou Art", 
        lyrics: "O Lord my God! When I in awesome wonder...",
        audio: "https://www.sample-videos.com/audio/mp3/wave.mp3"
    }
];

// Function to Display Hymns
function displayHymns(filter = "") {
    const hymnList = document.getElementById("hymnList");
    hymnList.innerHTML = ""; // Clear previous hymns

    const filteredHymns = hymns.filter(hymn => hymn.title.toLowerCase().includes(filter.toLowerCase()));

    if (filteredHymns.length === 0) {
        hymnList.innerHTML = `<p>No hymns found.</p>`;
        return;
    }

    filteredHymns.forEach(hymn => {
        const hymnCard = document.createElement("div");
        hymnCard.classList.add("hymn-card");
        hymnCard.innerHTML = `
            <h2>${hymn.title}</h2>
            <p>${hymn.lyrics}</p>
            <audio controls>
                <source src="${hymn.audio}" type="audio/mpeg">
                Your browser does not support the audio element.
            </audio>
        `;
        hymnList.appendChild(hymnCard);
    });
}

// Search Functionality (Trigger Search on Button Click)
document.getElementById("searchButton").addEventListener("click", () => {
    const searchTerm = document.getElementById("searchBar").value;
    displayHymns(searchTerm);
});

// Initial Load
displayHymns();
